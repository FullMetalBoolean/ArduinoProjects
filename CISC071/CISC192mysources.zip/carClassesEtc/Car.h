/* Car.h - Definition file */

#ifndef CAR_H
#define CAR_H

#include <string>

using std::string;

class Car
{
	private:
		int	 yearModel;					// Holding the car's year model
		string make;						// Holding the make of the car
		string color;						// Holding the car's current speed

	public:
		// Constructor
		Car(int, string, string);					

		// Mutators
		void drive(int miles);		
		
		// Accessors
		int	 getyearModel() const	// Returns the car's year model.
		{ return yearModel; }			

		string getMake() const			// Returns the make of the car.
		{ return make; }

		int	 getColor() const			// Returns the car's current speed.
		{ return color; }
};
#endif
