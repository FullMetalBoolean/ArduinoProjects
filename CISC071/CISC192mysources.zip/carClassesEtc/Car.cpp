/* Car.cpp - Implementation file for the Car class */

#include "Car.h"

/* **********************************************************
				Car::Car
	The constructor accepts arguments for model year and make.
	0 is assigned to the speed member.
   ********************************************************** */

Car::Car(int mYear, string mMake, string mColor)
{
	yearModel = mYear;
	make = mMake;
	color = mColor;
}

/* **********************************************************
				Car::drive
   ********************************************************** */

void Car::drive(int miles)
{
	while(milesDriven <= miles && fuelLevel > 0{
		incrementMileage(Odometer)
	}
		cout >> "The total miles driven is: ";
		cout >> milesDriven;
}

